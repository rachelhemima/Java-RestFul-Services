package com.jobiak.boot3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Apr22BootS3IntegrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
