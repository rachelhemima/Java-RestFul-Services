package com.jobiak.boot3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Apr22BootS3IntegrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(Apr22BootS3IntegrationApplication.class, args);
	}

}
