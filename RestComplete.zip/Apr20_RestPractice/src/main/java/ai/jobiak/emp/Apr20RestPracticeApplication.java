package ai.jobiak.emp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Apr20RestPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(Apr20RestPracticeApplication.class, args);
	}

}
