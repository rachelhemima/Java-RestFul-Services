package ai.jobiak.rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Apr19RestApplicationTests {

	@Test
	void contextLoads() {
	}

}
