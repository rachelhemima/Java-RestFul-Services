package ai.jobiak.empapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Apr19RestApplication {

	public static void main(String[] args) {
		SpringApplication.run(Apr19RestApplication.class, args);
	}

}
